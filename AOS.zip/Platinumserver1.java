import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;


public class Platinumserver1{

	public static void main(String[] args) throws IOException {
		ServerSocket PlatGroupServerSock = new ServerSocket(7077);
		try {
			System.out.println("Platinum Server is up and running");
			Item item = new Item(1,"airpods", 250, 4);
			Item item2 = new Item(2,"Bottle", 120, 5);
			Item item3 = new Item(3,"Trolly", 190, 3);
			List<Item> itemList = new ArrayList<Item>();
			itemList.add(item3);
			itemList.add(item2);
			itemList.add(item);
			// send items list to client

			System.out.println("Platinum Group server is establishing connection");

			// send items list to middle server
			Socket soc = PlatGroupServerSock.accept();
			InputStreamReader in = new InputStreamReader(soc.getInputStream());
			BufferedReader buffer = new BufferedReader(in);
			System.out.println("from middle server " + buffer.readLine());
			PrintWriter p = new PrintWriter(soc.getOutputStream());
			StringBuffer buff = new StringBuffer();
			
			for (Item items : itemList) {
				System.out.println();
				buff.append(items.index + " "+items.itemName + " " + items.itemPrice + " " + items.itemQuantity+"\\n");
			}
			p.println(buff.toString());
			p.flush();
			 String itemListClient=buffer.readLine();
			 itemListClient = itemListClient.replace("\\", "");
				String[] rec = itemListClient.split("n");
				int itemNum = Integer.parseInt(rec[0]);
				int itemQuan =Integer.parseInt(rec[1]);
				int points=Integer.parseInt(rec[2]);
			
			
				if(itemNum==item.index) {
					int totalprice=itemQuan*item.itemPrice;
					System.out.println("Total cost for items selected "+totalprice);
					points=points-totalprice;
					System.out.println("Total points after purchase "+points);
					p.println(points);
					p.flush();
				
					
				}
				
		}
		 catch (Exception e) {
				PlatGroupServerSock.close();
			} finally {
				PlatGroupServerSock.close();
			}
	}
}