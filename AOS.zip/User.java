
//package com.kServer.User;

public class User {
String userName;
String password;
String group;
int points;
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getGroup() {
	return group;
}
public void setGroup(String group) {
	this.group = group;
}
public int getPoints() {
	return points;
}
public void setPoints(int points) {
	this.points = points;
}

public User(String userName,
String password,
String group,
int points) {
	this.userName = userName;
	this.password= password;
	this.group = group;
	this.points = points;
	
}
}
