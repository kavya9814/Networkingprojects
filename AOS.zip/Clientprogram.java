import java.io.*;
import java.net.*;
import java.util.*;

public class Clientprogram {
	public static void main(String[] args)throws IOException {
		Socket sock = new Socket("172.20.20.20", 6801);
		System.out.println("client is establishing connection");
		PrintWriter p = new PrintWriter(sock.getOutputStream());
		p.println("Connection to client successful ");
		p.flush();
		InputStreamReader input = new InputStreamReader(sock.getInputStream());
		BufferedReader b = new BufferedReader(input);
		String line = b.readLine();
		System.out.println("" + line);
		System.out.println("Enter Username and password ");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Username :");
		String user = sc.nextLine();
		System.out.println("Enter valid password: ");
		String pwd = sc.nextLine();
		p.println(" " + user);
		p.println(" " + pwd);
		p.flush();
		String line2 = b.readLine();
		System.out.println("Client Side..." + line2);
		String resp = b.readLine().toString();
		// get the itemslist from server
		resp = resp.replace("\\", "");
		String[] rec = resp.split("n");
		String firstLine = "Index ItemName ItemPrice ItemQuantity";
		System.out.println(firstLine);
		for (String string : rec) {
			System.out.println(string);

		}
		
		Scanner sc2 =new Scanner(System.in);
		System.out.println("Enter Item number and quantity ");
		int item=sc.nextInt();
		int quan=sc.nextInt();
		p.println(item+"\\n"+quan);
		p.flush();
		System.out.println("Done Execution");
		
	}

}
