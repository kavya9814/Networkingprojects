//package com.Server;
import java.net.*;
import java.io.*;
import java.util.*;
//import java.lang.Thread;
//import com.Serverproj1;

public class MiddleServer {
	public static void main(String[] args) throws IOException{
		ServerSocket s = new ServerSocket(6801);
		try {
			Socket soc = s.accept();
			System.out.println("Middle Server is ready to be connected");
			InputStreamReader in = new InputStreamReader(soc.getInputStream());
			BufferedReader buffer = new BufferedReader(in);
			String string = buffer.readLine();
			System.out.println(" " + string);
			PrintWriter p = new PrintWriter(soc.getOutputStream());
			p.println("Connected to server");
			p.flush();
			File f = new File("C:/Users/kavya/OneDrive/Desktop/Java/UserList.txt");
			String username = buffer.readLine();
			username = username.trim();
			System.out.println(" Username : " + username);
			String password = buffer.readLine();
			password = password.trim();
			System.out.println(" password : " + password);
			String line, usr, pwd, group, points;
			BufferedReader buf3 = new BufferedReader(new FileReader(f));
			List<User> userList = new ArrayList<User>();
			while ((line = buf3.readLine()) != null) {
				usr = line.split(" ")[0];
				pwd = line.split(" ")[1];
				group = line.split(" ")[2];
				points = line.split(" ")[3];
				if (!points.contains("Points")) {
					User user = new User(usr.trim(), pwd.trim(), group.trim(), Integer.parseInt(points.trim()));
					userList.add(user);
				}
			}
			for (User user : userList) {
				if (username.equals(user.userName) && password.equals(user.password)) {
					System.out.println("User Login Successful");
					p.println("Succesful login");
					p.flush();
				
				if (user.group.equals("Silver")) {
					System.out.println("Connecting to Silver Server");
					
					
				} else if (user.group.equals("Platinum")) {
					System.out.println("Connecting to Platinum Server");

				} else if (user.group.equals("Gold")) {
					System.out.println("Connecting to Gold Server");
				}
				else {
					System.out.println("Not a valid Group");
				}
				Socket ClientSock = new Socket("172.20.20.20",7077);
				System.out.println(user.group);
				System.out.println("Silver Server is ready to be connected");
				PrintWriter scs = new PrintWriter(ClientSock.getOutputStream(), true);
				scs.println("Connection to middle server successful ");
				
				
				 BufferedReader newIn = new BufferedReader(new InputStreamReader(ClientSock.getInputStream()));
				 String resp = newIn.readLine();		
				 p.println(resp);
				p.flush();
				String itemListClient = buffer.readLine();
				//System.out.println("itemListClient" +itemListClient);
				scs.println(itemListClient+"\\n"+user.points);
				scs.flush();
				String RemainPoints=newIn.readLine();
				System.out.println("Points remaining for user "+RemainPoints);
				ClientSock.close();
				ClientSock.close();
				break;
				}
					
				}
	}
			catch (Exception e) {
				s.close();
				
				e.printStackTrace();
			}finally {
				s.close();
			}
	}
}
